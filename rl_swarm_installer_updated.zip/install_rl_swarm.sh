#!/bin/bash

# ============
# rl-swarm Mac 一键部署脚本
# 适配 Apple Silicon（M1/M2/M4）
# ============

echo "🧪 开始部署 Gensyn RL Swarm 节点..."

# 1. 安装 Homebrew（如果未安装）
if ! command -v brew &>/dev/null; then
    echo "🧰 未检测到 Homebrew，正在安装..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
else
    echo "✅ Homebrew 已安装"
fi

# 2. 安装 Python 3.10、Node.js、Yarn
echo "📦 安装 Python、Node.js、Yarn..."
brew install python@3.10 node
corepack enable
npm install -g yarn

# 3. 检查 python3.10 路径
PYTHON310_PATH="/opt/homebrew/bin/python3.10"
if [ ! -f "$PYTHON310_PATH" ]; then
    echo "❌ 未找到 python3.10，确保其已通过 Homebrew 正确安装"
    exit 1
else
    echo "✅ 使用 Python: $PYTHON310_PATH"
fi

# 4. 克隆 rl-swarm 仓库
echo "📥 克隆 rl-swarm 仓库..."
git clone https://github.com/gensyn-ai/rl-swarm.git || {
    echo "❌ 克隆失败，可能目录已存在"; exit 1;
}
cd rl-swarm

# 5. 创建虚拟环境并激活
echo "🐍 创建 Python 虚拟环境..."
rm -rf .venv
$PYTHON310_PATH -m venv .venv
source .venv/bin/activate

# 6. 设置内存限制（推荐 MPS 设置）
echo "🧠 设置 PYTORCH MPS 高水位限制为 0.0"
export PYTORCH_MPS_HIGH_WATERMARK_RATIO=0.0
echo 'export PYTORCH_MPS_HIGH_WATERMARK_RATIO=0.0' >> ~/.zshrc
echo "🔧 已将内存设置加入 ~/.zshrc"

# 7. 启动节点
echo "🚀 启动 Swarm 节点..."
chmod +x run_rl_swarm.sh
./run_rl_swarm.sh

echo "🎉 节点已启动，请根据提示选择模型并登录账户！"
