#!/bin/bash

# 检查并安装 Homebrew
if ! command -v brew &> /dev/null; then
    echo "📦 Homebrew 未安装，正在安装 Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    echo 'eval "$(/opt/homebrew/bin/brew shellenv)"' >> ~/.zprofile
    eval "$(/opt/homebrew/bin/brew shellenv)"
else
    echo "✅ Homebrew 已安装"
fi

# 检查并安装 Node.js
if ! command -v node &> /dev/null; then
    echo "📦 Node.js 未安装，正在通过 Homebrew 安装..."
    brew install node
else
    echo "✅ Node.js 已安装"
fi

# 启用 Corepack（管理 Yarn）
echo "🔧 启用 Corepack..."
corepack enable

# 时间同步逻辑增强：确保系统时间与 HiveMind 网络一致

# 检查 sntp 是否存在，否则安装
if ! command -v sntp &> /dev/null; then
    echo "📦 sntp 命令未找到，正在安装 ntp 包..."
    brew install ntp
fi

# 使用日本国家级 NTP 服务器同步时间
echo "🕒 正在使用 ntp.nict.jp 同步时间..."
sudo sntp -sS ntp.nict.jp || echo "⚠️ 时间同步失败，请检查网络连接"

# 等待时间同步稳定后再继续
sleep 5




# ===============
# Gensyn RL-Swarm 一键部署脚本（优化版）
# 适配 macOS Apple Silicon (M1/M2/M4) + 小内存配置
# ===============

set -e

echo "🧪 开始部署 Gensyn RL Swarm 节点..."

# Step 0: 同步系统时间，避免 Hivemind 时间误差错误
echo "⏱ 同步系统时间..."
sudo sntp -sS time.apple.com || echo "⚠️ 时间同步失败（可能需要安装 ntp 或手动设置）"

# Step 1: 安装 Homebrew（如果未安装）
if ! command -v brew &>/dev/null; then
    echo "🧰 未检测到 Homebrew，正在安装..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
else
    echo "✅ Homebrew 已安装"
fi

# Step 2: 安装 Python 3.10、Node.js、Yarn
echo "📦 安装 Python、Node.js、Yarn..."
brew install python@3.10 node || true
